#include <sys/time.h>
#include <ucontext.h>
ucontext_t mainContext;

struct myThread mainThread;
struct myThread *currentThread;

//long period_t;

struct itimerval timerVal;

int cancelCurrent = 0;
//int totalCount = 0;

struct queueStr readyQueue, finishQueue;


void startTime(){
	setitimer(ITIMER_REAL, &timerVal, 0);
}

void stopTime(){
	setitimer(ITIMER_REAL, 0, 0);
}

void queueInit(struct queueStr* queue){
	queue -> front = NULL;
       	queue -> rear = NULL;
	queue -> numOfNodes= 0;
}


int queueSize(struct queueStr *queue){
	return queue -> numOfNodes;
}

//We enqueue the given thread node into the list
int enqueueThreadQueue(struct queueStr *queue, struct myThread* thread){
	
	struct threadQueueNode* threadNode = (struct threadQueueNode *)malloc(sizeof(struct threadQueueNode));

	if(!threadNode){
		printf("Thread node was not created");
		return 0;
	}

	threadNode -> threadStr = thread;
	threadNode -> next = NULL;

	//if no node is present in ready queue 
	if(!queue -> rear){
		queue -> rear = threadNode;
		queue -> front = threadNode;
		
	}else{//otherwise add to end of list
		queue -> rear -> next = threadNode;
		queue -> rear = threadNode;
	}
	
	//increase number of nodes
	queue -> numOfNodes += 1;

	return 1;
}


//Dequeue a node from the front
struct myThread* dequeueThreadQueue(struct queueStr* queue){
	if(queue -> rear == NULL){
		printf("Cannot dequeue thread, Queue is Empty\n");
		return NULL;
	}
	
	struct threadQueueNode* threadNode = (struct threadQueueNode*)malloc((sizeof(struct threadQueueNode)));
	
	threadNode = queue -> front;
	queue -> front = queue -> front -> next;

	struct myThread* temp = threadNode -> threadStr;

	queue -> numOfNodes -= 1;
	free(threadNode);

	return temp;
}


//Search a thread with specific thread id
struct myThread* getQueueThread(struct queueStr* queue, int threadID){
	if(!queue -> rear){
//		printf("There are no nodes in queue");
		return NULL;
	} 

	struct threadQueueNode* temp = queue -> front;
	
	struct myThread* data = 0;

	while(temp){

		if(temp -> threadStr -> threadID  == threadID){
			data = temp -> threadStr;
			return data;
		}
		temp = temp -> next;
	}
	
//	printf("The node with threadID %d was not found\n", threadID);
	return NULL;
}


//Remove any node that whos work is done
int removeQueueThread(struct queueStr* queue, struct myThread* thread){
	
	struct threadQueueNode* temp = queue -> front;
	struct threadQueueNode* tempPrev = NULL;

	if(temp != NULL && temp -> threadStr -> threadID == thread -> threadID){
		
		queue -> front = temp -> next;
		free(temp);
		return 1;
	}

	while(temp != NULL && temp -> threadStr -> threadID != thread -> threadID){
		tempPrev = temp;
		temp = temp -> next;
	}

	if(temp == NULL){
//		printf("The given node with thread ID : %d could not be found\n",thread-> threadID);
		return 0;
	}
	
	//remove the node from the list
	if(temp -> threadStr -> threadID == thread -> threadID){ 
		printf("Found\n");
		tempPrev -> next = temp -> next;
	}
	
	free(temp);
	return 1;
}

//Scheduler process
void scheduler(){
	struct myThread* prevThread = NULL;
	struct myThread* nextThread = NULL;
	
	//printf("SWITCH");
	if(getcontext(&mainContext) == -1){
		printf("There was an eeror getting the context");
		return;
	}

	prevThread = currentThread;

	if(!cancelCurrent){
		int succ = enqueueThreadQueue(&readyQueue, prevThread);

		if(!succ) printf("The enqueue operation of thread was not successful");
	}

	nextThread = dequeueThreadQueue(&readyQueue);

	if(nextThread == NULL){
		printf("No thread was present to be dequeued");
	}

	currentThread = nextThread;

	startTime();

	if(swapcontext(&prevThread -> threadContext, &nextThread -> threadContext) == -1){
		printf("Swapping error\n");
	}

}
