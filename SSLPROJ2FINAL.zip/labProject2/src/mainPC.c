#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "myThread.c"
#define PRODUCERS 2
#define CONSUMERS 2
#define BUFFERS 6

struct myThread_mutex m1, m2;

struct myThread producers[PRODUCERS];
struct myThread consumers[CONSUMERS];
int buffer[BUFFERS];
int in = 0;
int out = 0;
int empty = 5;
int full = 0;
int itemsProduced = 0;
int itemsConsumed = 0;

void waitCS(int *countingSemaphore){
	while(1){
		
		myThread_mutex_lock(&m1);
		if(*countingSemaphore <= 0){
			myThread_mutex_unlock(&m1);
			continue;
		}else{
			(*countingSemaphore)-=1;
			myThread_mutex_unlock(&m1);
			break;
		}
	 //startTime();	
	 //myThread_yield();
	 //stopTime();
	}
	
}

void signalCS(int* countingSemaphore){
	myThread_mutex_lock(&m1);
	(*countingSemaphore) += 1;
	myThread_mutex_unlock(&m1);

}

void *producer(void* id){
	printf("here");
	while(1){
		itemsProduced++;
		
		waitCS(&empty);
	//	printf("empty:%d",empty);
		myThread_mutex_lock(&m2);
		if(buffer[in] != -1){
			printf("Sync error! Buffer was overwrote!\n");
			return NULL;
		}

		buffer[in] = itemsProduced;
		printf("Producer %d placed %d in buffer with index %d\n",id, itemsProduced, in);
	//	printf("In producer");
		in = (in + 1)% BUFFERS;
		//myThread_yield();
		//sleep(2);
		myThread_mutex_unlock(&m2);
		signalCS(&full);
	//	printf("Full: %d",full);
		myThread_yield();
	//	sleep(2);	
	}

}


void *consumer(int id){
	while(1){	
		waitCS(&full);
	//	printf("Full: %d", full);
		myThread_mutex_lock(&m2);

		itemsConsumed = buffer[out];

		if(itemsConsumed == -1){
			printf("Error");
		}
	//	printf("in consumer");
		printf("Consumer %d consumed %d from buffer with index %d\n",id, itemsConsumed, out);
		buffer[out] = -1;
		out = (out + 1) % BUFFERS;
		//myThread_yield();
		//sleep(2);
		myThread_mutex_unlock(&m2);
		signalCS(&empty);
	//	printf("Empty: %d",empty);
		myThread_yield();
		//sleep(2);
	}

}

void producerConsumer(){
	int t;

	for(t = 0; t < PRODUCERS; t++){

		myThread_create(&producers[t], NULL, (void*)producer, (void*)(t));

	
	} 
	
	for(t = 0; t < CONSUMERS; t++){
		myThread_create(&consumers[t], NULL, (void*)consumer,(int*)t);
	}
		

	while(itemsConsumed < 10*BUFFERS);

	for(t = 0; t < PRODUCERS; t++){
		myThread_join(producers[t], NULL);
	}

	for(t = 0; t < CONSUMERS; t++){
		myThread_join(consumers[t], NULL);
	}
	
}

int main(){
	
	//printf("started");
	myThreadInit(50);
	myThread_mutex_init(&m1);
	myThread_mutex_init(&m2);

	struct myThread prodCon;
	int i;
	myThread_create(&prodCon, NULL, (void*)producerConsumer, NULL);

	for(i = 0; i < BUFFERS; i++){
		buffer[i] = -1;
	}	
	
	while(itemsConsumed < 10*BUFFERS);

	printf("Stopped as items produced by %d and consumed by %d reached 10*%d[Size of buffers]",PRODUCERS, CONSUMERS, BUFFERS);

}
