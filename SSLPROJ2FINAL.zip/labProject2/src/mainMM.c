#include "myThread.c"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#define R1 4
#define C1 4
#define C2 4
 

//We use each thread for parallel multiplication of values of matrix
void* multiply(void* arg) {

    int *value = (int *)arg; 
    int i = 0, j = 0; 
      
    int currentData = value[0]; 
    for (i = 1; i <= currentData; i++) 
           j += value[i]*value[i+currentData]; 
      
    int *val = (int*)malloc(sizeof(int)); 
         *val = j;
	return val; 
} 
  

int main() { 
//Inititalize our myThread
    
	myThreadInit(5000); 
    
    	int matrixOne[R1][R1];  
    	int matrixTwo[R1][R1];  
      
      
    	int r1=R1,c1=R1,r2=R1,c2=R1,i,j,k; 
  
  
    	// Fill our matrix with random values in range 0-9 using rand for matrixOne and Two 
    	for (i = 0; i < r1; i++)  
            for (j = 0; j < c1; j++)  
                   matrixOne[i][j] = rand() % 10;  
            
       
    	for (i = 0; i < r2; i++)  
            for (j = 0; j < c2; j++)  
                   matrixTwo[i][j] = rand() % 10;  
     
    	// Output the generated Matrix          
    	for (i = 0; i < r1; i++){ 
        	for(j = 0; j < c1; j++) 
            		printf("%d ",matrixOne[i][j]); 
        	printf("\n"); 
    	} 
                               
    	for (i = 0; i < r2; i++){ 
        	for(j = 0; j < c2; j++) 
            		printf("%d ",matrixTwo[i][j]); 

        	printf("\n");     
    	} 
      
      
    	int sizeOfResultant = r1*c2; 
      
      
    	//creating threads for multiplication       
    	struct myThread *threads; 
    	threads = (struct myThread*)malloc(sizeOfResultant*sizeof(struct myThread)); 
      
    	int x = 0; 
    	int* value = NULL; 
 
 	clock_t start, end;
	double cpuTimeUsed;
	start = clock();
    
	for (i = 0; i < r1; i++) 
        	for (j = 0; j < c2; j++){ 
                 
               //storing the respective elemnts from the above matrices  
            	value = (int *)malloc((sizeOfResultant)*sizeof(int)); 
            	value[0] = c1; 
      
            	for (k = 0; k < c1; k++) value[k+1] = matrixOne[i][k]; 
      
            	for (k = 0; k < r2; k++) value[k+c1+1] = matrixTwo[k][j]; 
     		
             	//creating threads 
                myThread_create(&threads[x++], NULL, multiply, (void*)(value)); 
                  
                    } 
      
    printf("OUTPUT MATRIX:");
    
   
    for (i = 0; i < sizeOfResultant; i++) { 
      int** retval;
      //using join to accumulate the return value  
	myThread_join(threads[i],(void**)retval); 
	
	while(retval == NULL)printf("aaa");	
    	//Printing the corresponding result element
  	printf("%d ",**(retval)); 
      	if ((i + 1) % c2 == 0)  printf("\n");
    

    /*For caluclating the execution time
	printf("finished!"); 
  	end = clock();
	cpuTimeUsed = ((double)(end - start))/CLOCKS_PER_SEC;  
 	printf("%f",cpuTimeUsed);
	*/
}
  return 0; 
} 
