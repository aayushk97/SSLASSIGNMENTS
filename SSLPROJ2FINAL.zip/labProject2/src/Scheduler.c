
void scheduler(){
	struct myThread *prev, *next = NULL;
	stopTime();

	if(getcontext(&mainContext) == -1){
		printf("Error while getting context\n");
		return;
	}
	printf("Here");
	prev = current;
	printf("%d", current-> threadID);
	if(!cancelCurrent) {
		enqueueThreadQueue(&readyQueue, prev);
	
	}else{
		cancelCurrent = 0;
	}

	next = dequeueThreadQueue(&readyQueue);

	if(next == NULL){
		printf("Error");
		return;
	}

	current = next;
	startTime();
	if(swapcontext(&prev -> threadContext, &next -> threadContext) == -1){
		printf("Error\n");
	}

}

/*struct myThread* mainThread;
struct myThread* current = NULL;

//Timer
struct itimerval timerVal;

//Handler

struct sigaction timerSignalAction;

void RRScheduler();
void startTimer();
ucontext_t schedulerContext;

void Dostuff(){
	printf("Switch\n");
}
static void manager(){
	raise(SIGALRM);
}
void schedulerInitializer(){
	getcontext(&schedulerContext);
	schedulerContext.uc_stack.ss_sp= malloc(32000000);
	schedulerContext.uc_stack.ss_size = 32000000;
	schedulerContext.uc_stack.ss_flags = 0;
	schedulerContext.uc_link = NULL;
	makecontext(&schedulerContext,(void(*)(void))&manager,NULL);

}
void signalHandlerinit(){
//	struct sigaction timerSignalAction;
//	memset(&timerSignalAction ,0, sizeof(timerSignalAction));
//	timerSignalAction.sa_sigaction = RRScheduler;
	timerSignalAction.sa_handler = &RRScheduler;
//	sigemptyset(&timerSignalAction.sa_mask);
//	timerSignalAction.sa_flags = SA_SIGINFO;
	sigaction(SIGALRM, &timerSignalAction,NULL);
	startTimer();	
}

void startTimer(){
	int period = 50;
	timerVal.it_value.tv_sec = period/1000000L;
	timerVal.it_value.tv_usec = period %1000000L;
	timerVal.it_interval = timerVal.it_value;
	printf("set timer");
	setitimer(ITIMER_REAL, &timerVal, NULL);
}

void stopTimer(){
	setitimer(ITIMER_REAL, 0,0);

}
void scheduler(){
	myThread *prev, *next = NULL;
	stopTime();

	if(getcontext(&maincontext) == -1){
		printf("Error");
		exit(EXIT_FAILURE);
	}

	prev = current;

	if(!cancelCurrent){
		enqueueThreadQueue(&readyQueue, prev);

	}else{
		cancelCurrent = 0;
	}

	next = dequeueThreadQueue(&readyQueue);

	if(next == NULL){
		printf("No thread present\n");
		return;
	
	}

	current = next;
	startTime();

	if(swapcontext(&prev -> threadContext, &next -> threadContext) == -1){
		printf("Error while swap\n");
	}

}


void RRScheduler(){
	struct myThread* temp;
	if(!readyQueueRear){
		exit(0);
	}
printf("queuenotempty\n");
	current = (struct myThread*)readyQueueRear->threadStr;
printf("currentT:%d",current->threadID);
	if(readyQueueRear == readyQueueHead){
		if(current -> state == 2)
		 exit(0);
	}else{
		if(current -> state == 2){
			dequeueThreadQueue();
		}else{
		//	temp = dequeueThreadQueue();
			enqueueThreadQueue(dequeueThreadQueue());
		}
	
	}	

	struct myThread* toExecute = (struct myThread*)readyQueueRear -> threadStr;
	printf("toexecuteT %d",toExecute-> threadID);
	if(toExecute != current){
		if(current -> state == 2){
			setcontext(&toExecute -> threadContext);
		}else{
			printf("current thread:%d, nextThread: %d", current -> threadID, toExecute->threadID);
			swapcontext(&current-> threadContext, &toExecute -> threadContext);
			printf("back %d\n", toExecute->threadID);
		}
	
	}

}*/
