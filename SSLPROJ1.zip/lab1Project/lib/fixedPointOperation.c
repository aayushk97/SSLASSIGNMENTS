//include the functions
#include <stdio.h>
#include <stdlib.h>

#define SHIFT_AMOUNT 16
#define SHIFT_MASK ((1 << SHIFT_AMOUNT) -1 )
#define MAXVAL32 ((1LL << 32) -1) 

//convert given floating point representation convert to  fixed point number

int32_t float2fix(double x){
	int32_t res;

	res =  x * (1 << SHIFT_AMOUNT);
	
	return (int32_t)res;
}




//Returns interger part from given fixed Point number

int getIntegerPart(int32_t val){
	return (val >> SHIFT_AMOUNT);
}




//Returns the frational part of fixed point in decimal representation

double getFractionalPart(int32_t val){
	return ((double)(val & SHIFT_MASK)/(1<<SHIFT_AMOUNT));
}



//converts fixed point to float point

float fixed2float(int32_t x){
	double res;

	res = x * ( 1 >> SHIFT_AMOUNT);

	return res;
}


//function to add 2 fixed point number

int32_t add(int32_t a, int32_t b){
	return (int32_t)(a + b);
}



//function to subtract 2 fixed point number

int32_t subtract(int32_t a, int32_t b){
	return (int32_t)(a - b);
}



//function to multiply 2 fixed point numbers

int32_t multiply(int32_t a,int32_t b){
	int64_t res;
	a = a >> (SHIFT_AMOUNT/2);
	
	b = b >> (SHIFT_AMOUNT/2);
	
	res = ((int64_t)a * (int64_t)b) >> (SHIFT_AMOUNT/2);
	res = res << (SHIFT_AMOUNT/2);
	if(res > MAXVAL32) return SHIFT_MASK;

	return res;
}


//function to calculate logBaseE from logBase2 for calculation of fixed Point exponentiation
int32_t logBaseE(u_int32_t val){
	if( val == 0 ) {
		printf("log has value infinity");
	}
	
	
	int32_t count = 0;
	int32_t b = 1U << SHIFT_AMOUNT-1;
	//printf("the value of b: %d",b);
	
	while( val < 1U << SHIFT_AMOUNT){
		val <<= 1;
		count -= 1U << SHIFT_AMOUNT;
	}

	while( val >= 2U << SHIFT_AMOUNT){
		val >>= 1;
		count += 1U << SHIFT_AMOUNT;
	}
	
	int32_t temp = val;
	for(size_t i = 0; i < SHIFT_AMOUNT; i++){
		temp = multiply(temp, temp);
		
		if( temp >= 2U << (u_int64_t) SHIFT_AMOUNT){
			temp >>= 1;
			count += b;
		}

		b >>= 1;
	}
	//printf("the value of logbase2 of %d is %d",val,y);
        	
	//convert base from log2 to loge
	return multiply(count,float2fix(0.69314718056));

}



//function to calculate e^x using Taylor series with x upto power of 7

int32_t expFixed(int32_t value){
	
	//using taylor series
	int32_t nvalue = value -1;
	int32_t temp = nvalue;
	int32_t fixedOne = float2fix(1);
	temp =  add(fixedOne, value/7);
	for(int i = 6; i > 0; i--){
		temp = add(fixedOne, multiply(temp, value/i));
	}
	//printf("the value of exponent of %d is %d",value,temp);
	return temp;	

}


//function to perform exponentiation as x^y = e^ylogBaseE(x)
int32_t exponentiation(float a, float b){
	int32_t afixed = float2fix(a);
	int32_t bfixed = float2fix(b);

	int32_t logFixeda = logBaseE(afixed);

	logFixeda = multiply(logFixeda, bfixed);
	//printf("value of yloga: %d", logFixeda);
	int32_t exp_xy = expFixed(logFixeda);
	
	return exp_xy;

}

//dummy main for internal testing
int main1(){
      float valueInp;
      printf("enter a float value:");
      scanf("%f", &valueInp);
      int32_t numOne = float2fix(valueInp);      
      printf("the fix value is: %d", numOne);

      float valInp2;
      printf("enter another float value:");
      scanf("%f", &valInp2);
      int32_t numTwo = float2fix(valInp2);
      printf("the fix value is: %d",numTwo);

      int32_t resultSum = add(numOne,numTwo);
      printf("The result of sum: %d", resultSum);

      int32_t resultSub = subtract(numOne, numTwo);
      printf("The result of sub: %d", resultSub);

      int32_t resultProd = multiply(numOne, numTwo);
      printf("The result of product is: %d", resultProd);
	
      int32_t exp_xy = exponentiation(valueInp,valInp2);
      printf("The value of exponentiation %d",exp_xy);
      return 0;
}
