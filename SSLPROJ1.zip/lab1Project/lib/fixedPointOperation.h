int32_t float2fix(double x);

int getIntegerPart(int32_t val);

double getFractionalPart(int32_t val);

float fixed2float(int32_t x);

int32_t add(int32_t a, int32_t b);

int32_t subtract(int32_t a, int32_t b);

int32_t multiply(int32_t a, int32_t b);

int32_t logBaseE(u_int32_t val);

int32_t expFixed(int32_t value);

int32_t exponentiation(float a, float b);


