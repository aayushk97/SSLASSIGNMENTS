#include<stdio.h>
#include<stdlib.h>


void floatMatrixMult(float *matrixfOne,float *matrixfTwo,int r1,int c1,int r2,int c2){
	int i, j ,k;
	float matrixMResult[r1][c2];
	for(i = 0; i < r1; i++){
		for(j = 0; j < c2;j++){
			matrixMResult[i][j] = 0;

			for(k = 0; k < r2; k++){
				float num1 = *((matrixfOne + i*c1)+k);
				float num2 = *((matrixfTwo + k*c2) + j);
			
				matrixMResult[i][j] += (num1 * num2);
			}
		}
	
	}

	for(i = 0; i < r1; i++){
		for(j = 0; j < c2; j++){
			printf(" %f", matrixMResult[i][j]);
		}
	}

}

void getCofactorfMatrix(float matrixfOne[getRows()][getRows()], float tempf[getRows()][getRows()],int p, int q, int n){
	int i = 0, j = 0, row, col;

	for(row = 0; row < n; row++){
		for(col = 0; col < n; col++){
			if(row != p && col != q){
				tempf[i][j] = matrixfOne[row][col];
				j++;
				if( j == n - 1){
					j = 0;
					i++;
				}
			
			}
		}
	
	}

}
int determinantFloat(float matrixfOne[getRows()][getRows()], int n){
	int Determinantf = 0;

	int r1 = getRows();
	
	if(n == 1) return matrixfOne[0][0];

	float tempf[r1][r1];
	int sign = 1;
	
	int i;

	for(i = 0; i < n; i++){
		getCofactorfMatrix(matrixfOne, tempf, 0, i, n);
		Determinantf += sign*matrixfOne[0][i]*determinantFloat(tempf, n-1);
		sign = -sign;
	} 

	return Determinantf;

}

void adjointf(float matrixfOne[getRows()][getRows()], float adjointfMatrix[getRows()][getRows()]){
	int r1 = getRows();
	if( r1 == 1){
		adjointfMatrix[0][0] = 1;
		return;
	}

	int sign = 1;
	float tempf[r1][r1];
	
	int i, j;

	for(i = 0; i < r1; i++){
		for(j = 0; j < r1; j++){
			getCofactorfMatrix(matrixfOne, tempf, i, j, r1);

			sign = ((i+j)%2 == 0)?1:-1;


			adjointfMatrix[j][i] = (sign)*(determinantFloat(tempf, r1-1));
		
		}
	}


}
int inversef(float matrixfOne[getRows()][getRows()], float matrixfInverse[getRows()][getRows()]){

	float determinantf = determinantFloat(matrixfOne, getRows());

	if(determinantf == 0){
		printf("Input matrix is singular. Inverse cannot be performed");
		return 0;
	}

	float adjointfMatrix[getRows()][getRows()];
	
	adjointf(matrixfOne, adjointfMatrix);
	
	int i, j;
	
	for(i = 0; i < getRows(); i++){
		for(j = 0; j < getCols(); j++){
			matrixfInverse[i][j] = adjointfMatrix[i][j]/(determinantf);
		}
	
	}

	return 1;


}

/*
int main(){

	float matrixfOne[4][4] = {{5.0, -2.0, 2.0, 7.0},{1.0, 0.0, 0.0, 3.0},{-3.0, 1.0, 5.0, 0.0},{3.0,-1.0, -9.0, 4.0}};
	int inv = 0;
	float matrixfInv[4][4];

	inversef(matrixfOne, matrixfInv);
	int i, j;
	for(i = 0; i < 4; i++){
		for(j = 0; j < 4; j++){
			printf(" %f",matrixfInv[i][j]);
		}
	}
	
	return 1;
}*/
