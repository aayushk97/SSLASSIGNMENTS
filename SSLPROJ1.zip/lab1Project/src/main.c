#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include "y.tab.h"

//library for fixed point operations
#include "../lib/fixedPointOperation.h"

//Operations for floating point matrix multiplication and inverse
#include "floatMatrixOperation.c"

extern FILE* yyin;

void matrixMultiplication(char* filename1, char* filename2){
	yyin = fopen(filename1,"r");
	yyparse();

	int r1 = getRows();
	int c1 = getCols();

	float matrixOne[r1][c1];
	getMatrix(matrixOne);

	yyrestart(yyin);

	yyin = fopen(filename2,"r");
	yyparse();

	int r2 = getRows();
	int c2 = getCols();

	float matrixTwo[r2][c2];
	getMatrix(matrixTwo);

	//To multiply using floating point representation
	//floatMatrixMult is defined in class floatMatrixOperation.c
	
	//floatMatrixMult((float*)matrixOne, (float*)matrixTwo,r1, c1, r2, c2);

	
	if(c1 != r2){
		printf("%d%d",r2,c1);
		printf("The given matrices are not multiplication compatible.");
		return;
	}

	int i,j ,k;
	int32_t matrixFixed[r1][c2];
	int32_t temp = 0;
	for(i = 0; i < r1; i++){
		for(j = 0; j < c2; j++){
			matrixFixed[i][j] = 0;
			temp = 0;
			for(k = 0; k < r2; k++){

				temp = multiply(float2fix(matrixOne[i][k]),float2fix(matrixTwo[k][j]));
				matrixFixed[i][j] = add(temp , matrixFixed[i][j]);

			} 
		}
	}

	

	for(i = 0; i < r1; i++){
		for(j = 0; j < c2; j++){
			printf("matrix[%d][%d]:IP: %d FP:%f\n",i,j, getIntegerPart(matrixFixed[i][j]),getFractionalPart(matrixFixed[i][j]));
		}
	}

}

void getCofactor(int32_t matrixFixed[getRows()][getCols()], int32_t matrixFixedCofac[getRows()][getCols()], int p, int q, int r1){
	int i = 0, j = 0;
	int row, col;
	for( row = 0; row < r1; row++){
		for(col = 0; col < r1; col++){
			if(row != p && col != q){
				matrixFixedCofac[i][j] = matrixFixed[row][col];
				j++;
			//	printf(" %d",matrixFixedCofac[i][j]);
				if( j == r1 - 1){
					j = 0; i++;
				}
			}
		}
		
	}
	


}

int32_t determinant(int32_t matrixFixed[getRows()][getCols()], int r1){
	
	int32_t deter = 0;
	
	if( r1 == 1 ) return  matrixFixed[0][0];

	int32_t matrixFixedCofac[getRows()][getRows()];

	int sign = 1;
	int k;
	int32_t temp;
	for(k = 0; k < r1; k++){
		getCofactor(matrixFixed, matrixFixedCofac, 0, k, r1);
		
		temp =multiply(matrixFixed[0][k], determinant(matrixFixedCofac, r1-1));
		
		temp =  sign*temp;
		deter = add(deter, temp);
		sign = -sign;
	}
	return deter;	

}

void adjoint(int32_t matrixFixed[getRows()][getCols()], int32_t adjointFixed[getRows()][getCols()]){
	int r1 = getRows();
	if(r1 == 1) {
		adjointFixed[0][0] = 1;
		return;
	}
	int sign = 1;
	int32_t temp[r1][r1];
	
	int i , j ;
	for(i = 0; i < r1; i++){
		for(j = 0; j < r1; j++){
			getCofactor(matrixFixed, temp, i, j , r1);

			sign = ((i+j)%2 == 0)?1:-1;

			adjointFixed[j][i] = (sign)*(determinant(temp, r1-1));
		}
	
	}

}

void matrixInverse(char* filename){
	yyin = fopen(filename, "r");
	yyparse();
        	
	int r1 = getRows();
	int c1 = getCols();
	
	if(r1 != c1) printf("The matrix is not inverse compatible");
		
	float matrixOne[r1][c1];
     	getMatrix(matrixOne);

//	To calculate inverse of floating point matrix using floating point operations	
//	float inverse[r1][r1];

//	inversef(matrixOne, inverse);
	int i, j;
		
	int32_t matrixFixed[r1][r1];

	for(i = 0; i < r1; i++){
		for(j = 0; j < r1; j++){
			matrixFixed[i][j] = float2fix(matrixOne[i][j]);
			//printf(" %d", matrixFixed[i][j]);		
		}
	}
	int32_t deter = determinant(matrixFixed, r1);

	printf("determinant is:%d\n", deter);
	
	if( deter == 0){ 
		printf("Input matrix is singular matrix. Inverse can't be computed.");
		return;
	}

	int32_t adjointFixed[r1][r1];
	int32_t inverseFixed[r1][r1];

	adjoint(matrixFixed, adjointFixed);
	
	
	for(i = 0; i < r1; i++){
		for(int j = 0; j < r1; j++){
		//	printf("  %lld\n",(long long)adjointFixed[i][j]*65536);
		//	printf("   %d",(long long)adjointFixed[i][j]*65536/deter );
			inverseFixed[i][j] = ((int64_t)adjointFixed[i][j]*65536)/(int64_t)deter;		
		}
	}
        	
	for(i = 0; i < r1; i++){
		for(int j = 0; j < r1; j++){
			printf(" matrix[%d][%d]: %f\n",i,j,(float)inverseFixed[i][j]/65536);
		//	printf("matrix[%d][%d]:%d IF:%d FP:%f",i,j,inverseFixed[i][j],getIntegerPart(inverseFixed[i][j]),getFractionalPart(inverseFixed[i][j]));
		
		}
		
	}
}

void calculateExponent(char* filename){
     	FILE* fileinput;

	float base, exponent;

	fileinput = fopen(filename,"r");

	if(fileinput == NULL){
		printf("Can't open file for reading\n");
	}
		fscanf(fileinput, "%f", &base);
		fscanf(fileinput, "%f", &exponent);

		int32_t result = exponentiation(base,exponent);
		printf("the result of exponentiation is IP: %d FP: %f", getIntegerPart(result), getFractionalPart(result));
}


int main(int argc, char *argv[]){
	
	int Op = atoi(argv[1]);
	
	clock_t start, end;              //To calculate execution time of fixed point operations
	double cpuTimeUsed;

	if(Op == 1) {
		start = clock();

		matrixMultiplication(argv[2],argv[3]);
		
		end = clock();
		cpuTimeUsed = ((double) (end-start))/CLOCKS_PER_SEC;
	}

	if(Op == 2){
		start = clock();	
		matrixInverse(argv[2]);
		end = clock();
		cpuTimeUsed = ((double) (end - start))/CLOCKS_PER_SEC;
	}

	if(Op == 3){
		calculateExponent(argv[2]);
	}

	printf("\nTime takes by the operation: %f", cpuTimeUsed);
}
