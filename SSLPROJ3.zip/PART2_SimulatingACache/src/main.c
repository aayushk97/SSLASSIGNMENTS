#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cachesim.c"
//Sizes of cache
int l1DataCacheSize;
int l1DataAssoc;
int l1InstrCacheSize;
int l1InstrAssoc;

//Associativity of caches
int l2CacheSize;
int l2Assoc;

//Cache line size
int cacheLineSize;

//Value of T for new replacement policy
int T;
int i = 0;

int readTrace(FILE* traceFile){
	char c[1000];
	char* address;
	printf("\n");
	int size2 = 0;
	int operation;
	while( fgets(c, sizeof c, traceFile) != NULL){

		if(sscanf(c,"%d %s", &operation, address) != 2){
			printf("formatting error");
			return 0;
		}

		switch(operation){
			case 0:
			        printf("data load reference");
				printf("%d %s\n", operation, address);
				loadInstructionOrData(false, level1Data, address,0);
				break;
			case 1:
				printf("Data Store reference\n");
				printf("%d %s\n", operation, address);
				dataStore(address, 16, 2);
				break;
			case 2:
				printf("Instruction load reference\n");
				printf("%d %s\n", operation, address);
				loadInstructionOrData(true, level1Instr, address,0);
				break;
			default:
				printf("Invalid operation ...exit");
				break;
		}
			
	}

	fclose(traceFile);
	return 1;
}

int main(int argc, char* argv[]){
	//Store contents of output in file output.txt
	freopen("output.txt", "a+", stdout);
	
	FILE *inputTraceFile;
	
	printf("value of num arguments: %d", argc);

	if(argc != 11){
		printf("whaaaat?");
	}
		
	l1DataCacheSize = atoi(argv[2]);
	l1InstrCacheSize = atoi(argv[3]);
	l2CacheSize = atoi(argv[4]);

	l1DataAssoc = atoi(argv[5]);
	l1InstrAssoc = atoi(argv[6]);
	l2Assoc = atoi(argv[7]);
	
	//printf("%s", argv[8]);
	cacheLineSize = atoi(argv[8]);

	printf("Input file is: %s",argv[9]);	
	inputTraceFile = fopen(argv[9], "r");
	

	T = atoi(argv[10]);
	
	cacheSimulatorInitialize(l1DataCacheSize, l1InstrCacheSize, l2CacheSize, l1DataAssoc, l1InstrAssoc, l2Assoc,cacheLineSize, T);

/*	TO PRINT THE CONTENTS OF CACHE INTIALLY
 	printf("Printing the data cache contents: \n");
	printCache(level1Data, (l1DataCacheSize*1024)/cacheLineSize/l1DataAssoc,l1DataAssoc);

	printf("Printing the instr cache contents: \n");
	printCache(level1Instr, (l1InstrCacheSize*1024)/cacheLineSize/l1InstrAssoc, l1InstrAssoc);

	printf("Printing the l2 cache contents\n");
	printCache(level2, (l2CacheSize*1024)/cacheLineSize/l2Assoc,l2Assoc);
*/	
	if(inputTraceFile == NULL) {
		printf("Failed to open");
		exit(0);
	}else{

		printf("value of cache %d\n", l1DataCacheSize);
		printf("Reading TraceFile");
	
		readTrace(inputTraceFile);
	}
	
//	TO PRINT THE CONTENTS OF CACHE AFTER THE OPERATION
 //	printf("Printing the data cache contents: \n");
   //     printCache(level1Data, (l1DataCacheSize*1024)/cacheLineSize/l1DataAssoc,l1DataAssoc);

       // printf("Printing the instr cache contents: \n");
       // printCache(level1Instr, (l1InstrCacheSize*1024)/cacheLineSize/l1InstrAssoc, l1InstrAssoc);

       // printf("Printing the l2 cache contents\n");
       // printCache(level2, (l2CacheSize*1024)/cacheLineSize/l2Assoc,l2Assoc);


	printf("\nMiss rate L1: %d \nMiss Rate L2: %d", cacheL1DMiss, cache2Miss);
	printf("\nHit rate L1: %d\n Hit Rate L2: %d", cacheL1DHit, cache2Hit);

	return 0;
}


