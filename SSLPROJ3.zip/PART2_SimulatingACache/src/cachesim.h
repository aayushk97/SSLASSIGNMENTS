

struct stack{
	int size;
	int array[100];	
};

struct set{
	int size;
	int firstAccess[100];
	int LastAccess[100];
	int tag[100];
	int valid[100];
	int dirty[100];
};

struct cache{
	int associativity;
	int blockSize;
	int cacheSize;
	struct set* cacheSet;
	struct stack* cacheStack;
};





