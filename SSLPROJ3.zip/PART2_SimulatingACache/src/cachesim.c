#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include "cachesim.h"

struct cache* level1Data;
struct cache* level1Instr;
struct cache* level2;

int cache1DataSizeBits;
int cache1InstrSizeBits;
int cache2SizeBits;

int cache1DSetBits;
int cache1ISetBits;
int cache2SetBits;

int blockSizeBits;

int l1DataTagLength;
int l1InstrTagLength;
int l2TagLength;

int cacheL1DHit;
int cacheL1IHit;
int cache2Hit;

int cacheL1DMiss = 0;
int cacheL1IMiss = 0;
int cache2Miss = 0;
int numOfAccess = 0;

//For replacement policy
int cacheL1DHigh;
int cacheL1DLow;

int cacheL1IHigh;
int cacheL1ILow;

int cache2High;
int cache2Low;

//Replacement policy parameter
int ReplacePolicyT;

//Initialises the stack and stack initially contains -1
void stackInit(struct stack* cacheStack, int Assoc){
	cacheStack -> size = Assoc;
	int i;
	for(i = 0; i < Assoc; i++){
		cacheStack -> array[i] = -1;
		//cacheStack -> AccessTime[i] = 0;
	}
}

//Initialises the set. It copies the values from stack, initialises the dirty bit and valid bit to zero.

void setInit(struct set* cacheSet, struct stack* cacheStack){
	cacheSet -> size = cacheStack -> size;
	int i;
	for(i = 0; i < cacheStack->size; i++){
		cacheSet -> tag[i] = cacheStack->array[i];
		cacheSet -> dirty[i] = 0;
		cacheSet -> valid[i] = 0;
		cacheSet -> firstAccess[i] = 0;
		cacheSet -> LastAccess[i] = 0;
	}

}


//function that initialises the cache
void cacheInit(struct cache* ca, int setNum, int assoc, int blockSize, int size){
        ca -> associativity = assoc;
        ca -> blockSize = blockSize;
        ca -> cacheSize = size;

        struct set* cacheSet = (struct set*)malloc(sizeof(struct set)*setNum);
        struct stack* cacheStack = (struct stack*)malloc(sizeof(struct stack)*setNum);
	//struct stack* cacheStackLP = (struct stack*)malloc(sizeof(struct stack)*setNum);

        int i;
        for(i = 0; i < setNum; i++){
                stackInit(&(cacheStack[i]), assoc);
		//stackInit(&(cacheStackLP[i]), (assoc/2));

                setInit(&(cacheSet[i]), &cacheStack[i]);

                ca -> cacheSet = cacheSet;
                ca -> cacheStack = cacheStack;
		//ca -> cacheStackLP = cacheStackLP;
        }
}


//this is where we define length of different feilds. Also takes cache_int function
void cacheSimulatorInitialize(int l1DataCacheSize, int l1InstrCacheSize, int l2CacheSize, int l1DataAssoc, int l1InstrAssoc, int l2Assoc, int cacheLineSize, int T){
	
	l1DataCacheSize = 1024*l1DataCacheSize;
	l1InstrCacheSize = 1024*l1InstrCacheSize;
	l2CacheSize = 1024*l2CacheSize;

	//for l1 Data cache
	blockSizeBits = log(cacheLineSize)/log(2);
	cache1DSetBits = log(l1DataCacheSize/(cacheLineSize*l1DataAssoc))/log(2);
	l1DataTagLength = 32 - blockSizeBits - cache1DSetBits;
	level1Data = (struct cache*)malloc(sizeof(struct cache));
	cacheInit(level1Data, l1DataCacheSize/cacheLineSize/l1DataAssoc,l1DataAssoc, cacheLineSize, l1DataCacheSize);
	//Set the parameters for replacement policy
	cacheL1DHigh = l1DataAssoc-1;
	cacheL1DLow = l1DataAssoc/2-1;

	//for l1 instr cache
        cache1ISetBits = log(l1InstrCacheSize/(cacheLineSize*l1InstrAssoc))/log(2);
        l1InstrTagLength = 32 - blockSizeBits - cache1ISetBits;
        level1Instr = (struct cache*)malloc(sizeof(struct cache));
        cacheInit(level1Instr, l1InstrCacheSize/cacheLineSize/l1InstrAssoc, l1InstrAssoc, cacheLineSize, l1InstrCacheSize);
	//Set the parameters for replacement policy
	cacheL1IHigh = l1InstrAssoc-1;
	cacheL1ILow = l1InstrAssoc/2-1;
	
	//for l2 cache
	cache2SetBits = log(l2CacheSize/(cacheLineSize*l2Assoc))/log(2);
        l2TagLength = 32 - blockSizeBits - cache2SetBits;
        level2 = (struct cache*)malloc(sizeof(struct cache));
        cacheInit(level2, l2CacheSize/cacheLineSize/l2Assoc, l2Assoc,cacheLineSize, l2CacheSize);
	cache2High = l2Assoc-1;
	cache2Low = l2Assoc/2-1;

	ReplacePolicyT = T;

	printf("cache initialised\n");
	printf("cache 1 Data high and low: %d %d: ",cacheL1DHigh,cacheL1DLow);
	printf("cache 1 Instr high and low: %d %d: ",cacheL1IHigh,cacheL1ILow);
	printf("cache 2 high and low: %d %d: ",cache2High,cache2Low);


}



//function that updates the set and a set is updated when there is a miss
void setUpdate(struct stack* cacheStack, struct set* cacheSet, int write, int tagValue, int removedValue){
	int i;

	for(i = 0; i < cacheSet-> size; i++){

		if(cacheSet -> tag[i] == removedValue){

			cacheSet -> tag[i] = tagValue;
			cacheSet -> valid[i] = 1;

			if(write == 1) cacheSet -> dirty[i] = 1;

		}
	}


}
//After 1st access
//void Upgrade()
//After T cache access
//void DownGrade()

//This function implements LRU stack.
// The value from the physical address is added to top of the stack. Also, able to remove the
// value froma specific index. When a value is removed from the stack every element above it is 
// shifted down by one element.
// Remove Index is the index of the stack in which element was found.
// When removeIndex = hitInIndex = -1
int pushInStack(struct stack* cacheStack,struct set* cacheSet, int tagValue, int removeIndex){
	int removedValue, i;
	
	removedValue = cacheStack -> array[removeIndex];
        
	cacheSet -> firstAccess[tagValue] += 1;
	cacheSet -> LastAccess[tagValue] = numOfAccess;
	printf("\nThe value of tag: %d and value of remove Index: %d", tagValue, removeIndex);
	//If it is accessed second time
	if(cacheSet -> firstAccess[tagValue] == 2) {
		//MOve -1 to it
		printf("Second Access\n");

		for(i = 0; i < (cacheStack -> size)/2 ; i++){
			if(i< removeIndex)	
				cacheStack -> array[i+1] = cacheStack -> array[i];
			
			
		}
			cacheStack -> array[0] = -1;

		for(i = (cacheStack -> size)/2 ; i < cacheStack ->size ; i++){
                                
                                       cacheStack -> array[i] = cacheStack -> array[i+1];
		}
                        
                        cacheStack -> array[cacheStack -> size -1] = tagValue;
	}else{
		
		//Perfomrs LRU for Low Pirority Group
		if(removeIndex >=0 && removeIndex <4){
			printf("When in LP group\n");
		//	if()
			for(i = 0; i < ((cacheStack-> size)/2); i++){
				if(i >= removeIndex){
					printf("Before: The value of array[%d%]: %d\n", i, cacheStack -> array[i]);	
					cacheStack -> array[i] = cacheStack -> array[i+1];
					printf("After:  The value of array[%d]: %d\n", i, cacheStack -> array[i]);
				}
			}

			cacheStack -> array[(cacheStack -> size/2) -1] = tagValue;
	//	cacheSet -> firstAccess[tagValue] += 1;
	 //       cacheSet -> LastAccess[tagValue] = numOfAccess;	
		
	
		}else {
			printf("When in HP group\n");
		//Performs LRU for High Priority Group
		//move all data values left the item is removed
			for(i = (cacheStack -> size)/2 ; i < cacheStack ->size ; i++){
				
				if(i >= removeIndex){
					cacheStack -> array[i] = cacheStack -> array[i+1];
				}
			}
			cacheStack -> array[cacheStack -> size -1] = tagValue;
		}
	}

	return removedValue;
}

//Downgrade if the cache line is not accessed for T accesses
int Downgrade(struct stack* cacheStack, struct set* cacheSet){
	int i;
	int ToDownGrade = -1;
	
	for(i = (cacheStack -> size/2)-1; i < (cacheStack -> size) ; i++){
		if(cacheStack -> array[i] != -1){
			if((numOfAccess - (cacheSet -> LastAccess[cacheStack -> array[i]])) >= ReplacePolicyT){
			 	ToDownGrade = cacheStack -> array[i];
				//Move all elements to left of it in HP stack
				int j;
				for(j = (cacheStack ->size) - 1; j < (cacheStack -> size/2) - 1; j--){
					if(j <= i){
						cacheStack -> array[j] = cacheStack -> array[j-1];
					}
					cacheStack -> array[(cacheStack -> size/2) -1] = -1;
				}
				//Move all elements in LP stack to left and place this element
				if(cacheStack -> array[(cacheStack -> size/2)] == -1) cacheStack -> array[(cacheStack -> size/2)] = ToDownGrade;
				else{
        				for(j = 0; j < (cacheStack -> size/2) ; j++){
                                
						cacheStack -> array[j] = cacheStack -> array[j+1];
			
					}	
                               

					printf("Downgrade\n");
					cacheStack -> array[(cacheStack -> size/2) - 1] = ToDownGrade; 
				}
			}
		}
	}
	return ToDownGrade;
}


//if it is present in set else return -1 if its a miss 
int isHit(struct stack* st, struct set* s, int value){
	int hitIndex = -1;
	int checkHit = 0;
	
	int i,j;
/*	for(i = 0; i < st->size; i++){
		if(s -> tag[i] == value && s-> valid[i] ==1) checkHit = 1;
	}
	//search the stack for that tag value and return the index in it
*/	for(j = 0; j < st->size; j++){
		if(st-> array[j] == value){ 
			hitIndex = j;
			//printf("hit Index changed");
		}
		printf("\nsearched %d value was %d\n",j, st->array[j]);
	}
	//printf("Hit Index in inHIt function: %d", hitIndex);
	return hitIndex;

}

//Function to determine if write back occurs
int isWriteBack(struct stack* cacheStack, struct set* cacheSet, int removedValueFromStack){
	int writeBackCheck = 0;
	int removeSetIndex = -1;
	
	int i;
	
	//Set the Tag value for that
	for(i = 0; i < cacheSet -> size; i++){
		if(cacheSet -> tag[i] == removedValueFromStack) removeSetIndex = i;
	}

	//If the cache line was dirty we set the writeBackCheck
	if(cacheSet -> dirty[removeSetIndex] == 1) writeBackCheck = 1;

	return writeBackCheck;
}



//This is a function that updates the cache. The push function is called to update each stack in the cache. The set update function is used to update each set in the cache
int cacheUpdate(struct cache* cacheToUpdate, int hitInIndex, int tagValue, int write, int setNumber){
	
	int removedValueFromStack;
	int writeBackIndicator;

	if(hitInIndex >=0 && hitInIndex <4) printf("High Priority.%d %d", tagValue, hitInIndex);
	if(hitInIndex >=4 && hitInIndex <8) printf("Low Priority. %d %d", tagValue, hitInIndex);	 
	
	if(cacheToUpdate -> associativity > 1){
		int wasDownGraded = Downgrade(&cacheToUpdate -> cacheStack[setNumber], &cacheToUpdate -> cacheSet[setNumber]);
	
		if(wasDownGraded != -1) printf("\n block %d was downGraded\n", wasDownGraded);
	}
	//Give the index where the entry was found and get the element and
	removedValueFromStack = pushInStack(&cacheToUpdate -> cacheStack[setNumber], &cacheToUpdate -> cacheSet[setNumber], tagValue, hitInIndex);

	//check if the current data that was removed has to be written back or its dirty bit is set
	
	writeBackIndicator = isWriteBack(&cacheToUpdate -> cacheStack[setNumber], &cacheToUpdate-> cacheSet[setNumber], removedValueFromStack);
	
	//set the values of the set corresponding to one accessesd	
	setUpdate(&cacheToUpdate -> cacheStack[setNumber], &cacheToUpdate -> cacheSet[setNumber], write, tagValue, removedValueFromStack);
	
	return writeBackIndicator;

}


void loadInstructionOrData(bool loadInstruction, struct cache* loadTocache, char* givenAddress, int size){
	//To convert hexadecimal to address
	numOfAccess++;	
	u_int32_t address = (int) strtol(givenAddress, NULL, 16);
	
	
	//printf("Address to write: %d", address);
	
	//Get the information from physical address as L1 D and L1 I cache is similar in 
	//paraemeters we can get value from any of them
	int blockValueL1 = address & ((1<<blockSizeBits)-1);
	int setNumberL1 = (address >> blockSizeBits)&((1<<cache1DSetBits)-1);
	int tagValueL1 = (address >> (blockSizeBits + cache1DSetBits))&((1 << l1DataTagLength)-1);
	
	printf("For L1 Data: The value of blockNumber, set Number, tagValue: %d %d %d\n", blockValueL1, setNumberL1, tagValueL1);
	int blockValueL2 = address & ((1<<blockSizeBits)-1);
        int setNumberL2 = (address >> blockSizeBits)&((1<<cache2SetBits)-1);
        int tagValueL2 = (address >> (blockSizeBits + cache2SetBits))&((1 << l2TagLength)-1);
	     
	printf("For L2:The value of blockNumber, set Number, tagValue: %d %d %d\n", blockValueL2, setNumberL2, tagValueL2);

	//Checking if data can fit into cache block
	//***INSERT SOME CODE*****
	
	//Check whether the block is present in any of caches
	int hitInL1, hitInL2;

	if(loadInstruction) hitInL1 = isHit(&(level1Instr ->cacheStack[setNumberL1]), &(level1Instr -> cacheSet[setNumberL1]), tagValueL1);
	else hitInL1 = isHit(&(level1Data -> cacheStack[setNumberL1]), &(level1Data -> cacheSet[setNumberL1]), tagValueL1);

        hitInL2 = isHit(&(level2 -> cacheStack[setNumberL2]), &(level2-> cacheSet[setNumberL2]), tagValueL2);
	
	printf("The hit values of L1 L2: %d %d\n", hitInL1, hitInL2);
	if(hitInL1 != -1){
                cacheL1DHit++;
                //STORE THE DATiA********** cacheUpdate(struct cache* ca, int removeIndex, int value, int write, int set_order)
                if(loadInstruction) cacheUpdate(level1Instr, hitInL1, tagValueL1, 0, setNumberL1);
		else cacheUpdate(level1Data, hitInL1, tagValueL1, 0, setNumberL1);


        }else{
                cacheL1DMiss++;


                if(hitInL2 != -1){
                        cache2Hit++;
                        //Copy instruction from L2 to L1D
                        if (!loadInstruction && cacheUpdate(level1Data, 0, tagValueL1, 0, setNumberL1)){
                        //        writebacks++;
                        }
			if(loadInstruction) cacheUpdate(level1Instr, 0, tagValueL1, 0, setNumberL1);

                        cacheUpdate(level2, hitInL2, tagValueL2, 0, setNumberL2);

                }else{
                        cache2Miss++;

                        //eviction
                        if (!loadInstruction && cacheUpdate(level1Data, 0, tagValueL1, 0, setNumberL1)){
                         //       writebacks++;
                        }
			 if(loadInstruction) cacheUpdate(level1Instr, 0, tagValueL1, 0, setNumberL1);

                        cacheUpdate(level2, 0, tagValueL2, -1, setNumberL2);



                }
	}
}

void dataStore(char *addressGiven, int size, char* data){
	int address = (int)strtol(addressGiven, NULL, 16);
	numOfAccess++;
	//we also need to convert the data into appropriate format
/*	char charData[size], subString[2];
	int a;
	
	for(a = 0; a < size; a++){
		strncpy(subString, (data + a* 2), 2);
		charData[a] = (char)strtol(subString, NULL, 16);
	
	}
*/
	//calculate the parameters for caches 
	int blockValueL1 = address & ((1 << blockSizeBits) -1);
	int setNumberL1 = (address >> blockSizeBits)&((1<<cache1DSetBits)-1);
        int tagValueL1 = (address >> (blockSizeBits + cache1DSetBits))&((1 << l1DataTagLength)-1);

        int blockValueL2 = address & ((1<<blockSizeBits)-1);
        int setNumberL2 = (address >> blockSizeBits)&((1<<cache2SetBits)-1);
        int tagValueL2 = (address >> (blockSizeBits + cache2SetBits))&((1 << l2TagLength)-1);

	int hitInL1 = isHit(&(level1Data -> cacheStack[setNumberL1]), &(level1Data -> cacheSet[setNumberL1]), tagValueL1);

        int hitInL2 = isHit(&(level2 -> cacheStack[setNumberL2]), &(level2-> cacheSet[setNumberL2]), tagValueL2);

	
	if(hitInL1 != -1){
		cacheL1DHit++;
		//STORE THE DATiA********** cacheUpdate(struct cache* ca, int removeIndex, int value, int write, int set_order)
		cacheUpdate(level1Data, hitInL1, tagValueL1, 1, setNumberL1);
		
	
	}else{
		cacheL1DMiss++;
		

		if(hitInL2 != -1){
			cache2Hit++;
			//Copy instruction from L2 to L1D
			if (cacheUpdate(level1Data, 0, tagValueL1, 1, setNumberL1)){
			//	writebacks++;
		 	}
			cacheUpdate(level2, hitInL2, tagValueL2, 1, setNumberL2);
		
		}else{
			cache2Miss++;
			
			//eviction
			if (cacheUpdate(level1Data, 0, tagValueL1, 1, setNumberL1)){
			//	writebacks++;
			}
			cacheUpdate(level2, 0, tagValueL2, 1, setNumberL2);
			
		
		
		}
		
		//Now data is both in L1D or L2.
		//Make the changes. For this we need line number.
		hitInL1 = isHit(&(level1Data -> cacheStack[setNumberL1]), &(level1Data -> cacheSet[setNumberL1]), tagValueL1);

		//copy the data from L1D to L2

		
	
	}
	//Copy data back to RAM
}

void printStack(struct stack* st){
	int i = 0;
	for(i = 0; i < st -> size; i++){
		printf("At the stack index %d ", i);
		printf("The value is %d \n", st -> array[i]);
	}
}

void printSet(struct set* set){
	int i;
	for(i = 0; i < set -> size; i++){
		printf("Within the set, at index %d ", i);
		printf("%d ,", set -> tag[i]);
		printf("%d ,", set -> valid[i]);
		printf("%d ,", set -> firstAccess[i]);
		printf("%d ,", set -> LastAccess[i]);
		printf("%d \n", set -> dirty[i]);
	}

}
void printCache(struct cache* ca, int set_num, int ways){

	int i = set_num;

	for(int i = 0; i < 2; i++){
		printf("For set %d :\n", i);
//		printStack(&(ca -> cacheStackHP)[i]);
		printStack(&(ca -> cacheStack)[i]);
		printSet(&(ca -> cacheSet[i]));
	}

}


